import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class playConnect4
{
    //Characters R and Y will represent the two players colors, Red and Yellow
    private static final char[] PLAYERS = {'R', 'Y'};
    
    //Dimensions of game board
    private final int width;
    private final int height;
    
    //grid of connect4 game board
    private final char[][] map;

    // how last move of player is stored
    private int lastCol = -1;
    private int lastTop = -1;
    
    
    //constructor
    public playConnect4(int w, int h)
    {
        width = w;
        height = h;
        map = new char[h][];
        
        //for loop initiates blank game board, . represents unused spaces
        for (int i = 0; i < h; i++)
        {
            Arrays.fill(map[i] = new char[w], '.');
        }
    }
    
    //this method get the string rep. of the row containing the last play
    public String horizontal()
    {
        return new String(map[lastTop]);
    }
    
  //this method get the string rep. of the col. containing the last play
    public String vertical()
    {
        StringBuilder sb = new StringBuilder(height);
        
        for (int i = 0; i < height; i++)
        {
            sb.append(map[i][lastCol]);
        }
        
        return sb.toString();
    }
    
  //this method get the string rep. of the forward diagonal containing the last play
    public String slashDiag()
    {
        StringBuilder sb = new StringBuilder(height);
        
        for (int i = 0; i < height; i++)
        {
            int w = lastCol + lastTop - i;
            
            if ( 0 <= w && w < width)
            {
                sb.append(map[i][w]);
            }
        }
        return sb.toString();
    }
    
    //this method get the string rep. of the backward diagonal containing the last play

    public String backslashDiag()
    {
        StringBuilder sb = new StringBuilder(height);
        
        for (int i = 0; i < height; i++)
        {
            int w = lastCol - lastTop + i;
            
            if (0 <= w && w < width)
            {
                sb.append(map[i][w]);
            }
        }
        return sb.toString();    
        }
    
    public static boolean contains(String str, String subString)
    {
        return str.indexOf(subString) >= 0;
    }
    
    //this method checks if the last play was a winning move and if the game should end.
    public boolean isWinningMove()
    {
        if (lastCol == -1)
        {
            System.err.println("Move has not been made yet.");  
            return false;
        }
        
        char sym = map[lastTop][lastCol];
        
        //winning streak with last play symbol
        String streak = String.format("%c%c%c%c" , sym, sym, sym, sym);
        
        //this checks if streak is in row, col, forward diagonal or backward diagonal
        return contains(horizontal(), streak) || 
            contains(vertical(), streak) || 
            contains(slashDiag(), streak) || 
            contains(backslashDiag(), streak);
        
    }
    
    //this method prompts player for col. 0-7, repeats until valid answer is given.
    public void choose(char symbol, Scanner input)
    {
        do
        {
            System.out.println("\nPlayer " + symbol + " turn: ");
            int col = input.nextInt();
            
            //checks if col. entered exists.
            if (!(0 <= col && col < width))
            {
                System.out.println("Column needs to be between 0 and " + (width - 1));
                continue;
            }
            
            //places symbol in first available row in col. chosen
            for (int h = height - 1; h >= 0; h--)
            {
                if (map[h][col] == '.')
                {
                    map[lastTop = h][lastCol = col] = symbol;
                    return;
                }
            }
            
            //prompted when column is full already and new one needs to be chosen.
            System.out.println("Column " + col + " is full already.");
        }
        while (true);
    }
    
    
    
    public String toString()
    {
        return IntStream.range(0, width).mapToObj(Integer::toString).collect
            (Collectors.joining()) + "\n" + Arrays.stream(map).map(String::new)
            .collect(Collectors.joining("\n"));
        
    }
    
    public static void main(String[] args)
    {
        try (Scanner input = new Scanner(System.in))
        {
            //dimensions of game board
            int height = 6;
            int width = 8;
            int moves = height * width;
            
            //creates board
            playConnect4 board = new playConnect4(width, height);
            
            //explains to user what to do
            System.out.println("Use 0-" + (width - 1) + " to choose a column.");
            //Displays blank board to user
            System.out.println(board);
            
            //switches players after each move, counting up until
            // maximum moves is reached or there is a winner
            for (int player = 0; moves-- > 0; player = 1 - player)
            {
                char symbol = PLAYERS[player];
                
                //asks the player to choose a col.
                board.choose(symbol, input);
                
                //prints out board with players new move
                System.out.println(board);
                
                //checks if player won, if not, players switch and game continues
                // if won, message is displayed.
                if (board.isWinningMove())
                {
                    System.out.println("\nPlayer " + symbol + " has won! Congrats!");
                    return;
                }
            }
            
            //prints out if maximum moves is reached and no winner.
            System.out.println("The game is over. No one is the winner. Play again?");
        }

    }

}
